"use strict";
(() => {
  var __defProp = Object.defineProperty;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);

  // src/adapters/chatgpt.ts
  var ChatGPTAdapter = class {
    constructor() {
      __publicField(this, "siteName", "ChatGPT");
    }
    matchesPage(url) {
      try {
        const parsed = new URL(url);
        const host = parsed.hostname.toLowerCase();
        return host === "chatgpt.com" || host === "chat.openai.com" || host.endsWith(".chatgpt.com");
      } catch {
        return false;
      }
    }
    matchesRequest(_url, method) {
      if (method && method.toUpperCase() !== "POST") return false;
      return true;
    }
    getConversationId(pageUrl) {
      try {
        const parsed = new URL(pageUrl);
        const match = parsed.pathname.match(/\/c\/([a-zA-Z0-9_-]+)/);
        return match ? match[1] : null;
      } catch {
        const match = pageUrl.match(/\/c\/([a-zA-Z0-9_-]+)/);
        return match ? match[1] : null;
      }
    }
    extractUserPrompt(bodyString) {
      try {
        const body = JSON.parse(bodyString);
        if (!body || typeof body !== "object" || !Array.isArray(body.messages)) {
          return null;
        }
        let foundUserMessage = false;
        for (const m of body.messages) {
          if (m?.author?.role === "user") {
            foundUserMessage = true;
            if (!m.content || !Array.isArray(m.content.parts)) {
              return null;
            }
          }
        }
        if (!foundUserMessage) {
          return null;
        }
        const stringParts = [];
        for (let i = 0; i < body.messages.length; i++) {
          const m = body.messages[i];
          if (m?.author?.role === "user") {
            for (let j = 0; j < m.content.parts.length; j++) {
              if (typeof m.content.parts[j] === "string") {
                stringParts.push({ msgIndex: i, partIndex: j, text: m.content.parts[j] });
              }
            }
          }
        }
        if (stringParts.length === 0) {
          return null;
        }
        const joinedPrompt = stringParts.map((sp) => sp.text).join("\n\n");
        return {
          prompt: joinedPrompt,
          replaceWith: (redactedPrompt) => {
            const newBody = JSON.parse(bodyString);
            if (stringParts.length === 1) {
              const sp = stringParts[0];
              newBody.messages[sp.msgIndex].content.parts[sp.partIndex] = redactedPrompt;
            } else {
              const first = stringParts[0];
              newBody.messages[first.msgIndex].content.parts[first.partIndex] = redactedPrompt;
              for (let i = 1; i < stringParts.length; i++) {
                const sp = stringParts[i];
                newBody.messages[sp.msgIndex].content.parts[sp.partIndex] = "";
              }
            }
            return JSON.stringify(newBody);
          }
        };
      } catch {
        return null;
      }
    }
    classifyRequest(bodyString) {
      try {
        const body = JSON.parse(bodyString);
        if (!body || typeof body !== "object") {
          return { classification: "non-message", extracted: null };
        }
        if ("messages" in body) {
          if (!Array.isArray(body.messages)) {
            return { classification: "unknown-message-shape", extracted: null };
          }
          const extracted = this.extractUserPrompt(bodyString);
          if (extracted) {
            return { classification: "message", extracted };
          }
          return { classification: "unknown-message-shape", extracted: null };
        }
        return { classification: "non-message", extracted: null };
      } catch {
        return { classification: "non-message", extracted: null };
      }
    }
    getMessageSelectors() {
      return [
        '[data-message-author-role="assistant"]',
        '[data-message-author-role="user"]',
        ".agent-turn",
        ".user-turn",
        ".markdown",
        'div[data-testid^="conversation-turn-"]'
      ];
    }
  };

  // src/adapters/claude.ts
  var ClaudeAdapter = class {
    constructor() {
      __publicField(this, "siteName", "Claude");
    }
    matchesPage(url) {
      try {
        const parsed = new URL(url);
        const host = parsed.hostname.toLowerCase();
        return host === "claude.ai" || host.endsWith(".claude.ai");
      } catch {
        return false;
      }
    }
    matchesRequest(url, method) {
      if (method && method.toUpperCase() !== "POST") return false;
      try {
        const base = typeof window !== "undefined" && window.location ? window.location.origin : "https://claude.ai";
        const parsed = new URL(url, base);
        const path = parsed.pathname;
        return path.includes("/api/organizations/") && path.includes("/chat_conversations/") && (path.endsWith("/completion") || path.endsWith("/retry_completion") || path.includes("/completion"));
      } catch {
        return url.includes("/api/organizations/") && url.includes("/chat_conversations/");
      }
    }
    getConversationId(pageUrl) {
      try {
        const parsed = new URL(pageUrl);
        const match = parsed.pathname.match(/\/chat\/([a-zA-Z0-9_-]+)/);
        return match ? match[1] : null;
      } catch {
        const match = pageUrl.match(/\/chat\/([a-zA-Z0-9_-]+)/);
        return match ? match[1] : null;
      }
    }
    extractUserPrompt(bodyString) {
      try {
        const body = JSON.parse(bodyString);
        if (!body || typeof body !== "object") return null;
        if (typeof body.prompt === "string") {
          const originalPrompt = body.prompt;
          return {
            prompt: originalPrompt,
            replaceWith: (redactedPrompt) => {
              const updated = JSON.parse(bodyString);
              updated.prompt = redactedPrompt;
              return JSON.stringify(updated);
            }
          };
        }
        if (Array.isArray(body.messages)) {
          let userIdx = -1;
          for (let i = body.messages.length - 1; i >= 0; i--) {
            const m = body.messages[i];
            if (m?.role === "user") {
              userIdx = i;
              break;
            }
          }
          if (userIdx === -1) return null;
          const userMsg = body.messages[userIdx];
          if (typeof userMsg.content === "string") {
            return {
              prompt: userMsg.content,
              replaceWith: (redactedPrompt) => {
                const updated = JSON.parse(bodyString);
                updated.messages[userIdx].content = redactedPrompt;
                return JSON.stringify(updated);
              }
            };
          }
          if (Array.isArray(userMsg.content) && typeof userMsg.content[0]?.text === "string") {
            return {
              prompt: userMsg.content[0].text,
              replaceWith: (redactedPrompt) => {
                const updated = JSON.parse(bodyString);
                updated.messages[userIdx].content[0].text = redactedPrompt;
                return JSON.stringify(updated);
              }
            };
          }
        }
        return null;
      } catch {
        return null;
      }
    }
    classifyRequest(bodyString) {
      try {
        const body = JSON.parse(bodyString);
        if (!body || typeof body !== "object") {
          return { classification: "non-message", extracted: null };
        }
        if ("prompt" in body || "messages" in body) {
          if ("messages" in body && !Array.isArray(body.messages)) {
            return { classification: "unknown-message-shape", extracted: null };
          }
          const extracted = this.extractUserPrompt(bodyString);
          if (extracted) {
            return { classification: "message", extracted };
          }
          return { classification: "unknown-message-shape", extracted: null };
        }
        return { classification: "non-message", extracted: null };
      } catch {
        return { classification: "non-message", extracted: null };
      }
    }
    getMessageSelectors() {
      return [
        "[data-is-streaming]",
        ".font-claude-message",
        ".font-user-message",
        'div[data-testid="user-message"]',
        "div[data-test-render-count]",
        ".standard-markdown",
        'div[class*="ChatMessage"]'
      ];
    }
  };

  // src/adapters/index.ts
  var ADAPTERS = [
    new ChatGPTAdapter(),
    new ClaudeAdapter()
  ];
  if (false) {
    ADAPTERS.push(new MockSiteAdapter());
  }
  function getAdapterForUrl(url) {
    for (const adapter of ADAPTERS) {
      if (adapter.matchesPage(url)) {
        return adapter;
      }
    }
    return null;
  }

  // src/content/ui-notice.ts
  function showPrivacyNotice(message, durationMs = 6e3) {
    try {
      const existing = document.getElementById("ratchet-privacy-notice");
      if (existing) existing.remove();
      const notice = document.createElement("div");
      notice.id = "ratchet-privacy-notice";
      notice.setAttribute("role", "alert");
      Object.assign(notice.style, {
        position: "fixed",
        top: "20px",
        left: "50%",
        transform: "translateX(-50%)",
        backgroundColor: "#b91c1c",
        color: "#ffffff",
        padding: "12px 20px",
        borderRadius: "8px",
        fontSize: "14px",
        fontWeight: "600",
        fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
        boxShadow: "0 10px 15px -3px rgba(0, 0, 0, 0.4)",
        zIndex: "2147483647",
        display: "flex",
        alignItems: "center",
        gap: "10px",
        pointerEvents: "auto",
        transition: "opacity 0.3s ease"
      });
      const shieldSpan = document.createElement("span");
      shieldSpan.textContent = "\u{1F6E1}\uFE0F";
      shieldSpan.style.fontSize = "18px";
      const textSpan = document.createElement("span");
      textSpan.textContent = message;
      notice.appendChild(shieldSpan);
      notice.appendChild(textSpan);
      const target = document.body || document.documentElement;
      if (target) {
        target.appendChild(notice);
        setTimeout(() => {
          notice.style.opacity = "0";
          setTimeout(() => notice.remove(), 300);
        }, durationMs);
      }
    } catch {
    }
  }
  function showWarningNotice(message, durationMs = 6e3) {
    try {
      const existing = document.getElementById("ratchet-warning-notice");
      if (existing) existing.remove();
      const notice = document.createElement("div");
      notice.id = "ratchet-warning-notice";
      notice.setAttribute("role", "alert");
      Object.assign(notice.style, {
        position: "fixed",
        top: "70px",
        left: "50%",
        transform: "translateX(-50%)",
        backgroundColor: "#d97706",
        color: "#ffffff",
        padding: "10px 18px",
        borderRadius: "8px",
        fontSize: "13px",
        fontWeight: "600",
        fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
        boxShadow: "0 10px 15px -3px rgba(0, 0, 0, 0.4)",
        zIndex: "2147483647",
        display: "flex",
        alignItems: "center",
        gap: "10px",
        pointerEvents: "auto",
        transition: "opacity 0.3s ease"
      });
      const iconSpan = document.createElement("span");
      iconSpan.textContent = "\u26A0\uFE0F";
      iconSpan.style.fontSize = "16px";
      const textSpan = document.createElement("span");
      textSpan.textContent = message;
      notice.appendChild(iconSpan);
      notice.appendChild(textSpan);
      const target = document.body || document.documentElement;
      if (target) {
        target.appendChild(notice);
        setTimeout(() => {
          notice.style.opacity = "0";
          setTimeout(() => notice.remove(), 300);
        }, durationMs);
      }
    } catch {
    }
  }

  // src/content/interceptor-main.ts
  var RATCHET_DEBUG = window.__RATCHET_DEBUG__ === true;
  function summarizeJson(jsonStr) {
    try {
      const obj = JSON.parse(jsonStr);
      const recurse = (val) => {
        if (typeof val === "string") return `string(${val.length})`;
        if (Array.isArray(val)) return val.map(recurse);
        if (val && typeof val === "object") {
          const out = {};
          for (const k of Object.keys(val)) {
            out[k] = recurse(val[k]);
          }
          return out;
        }
        return val;
      };
      return recurse(obj);
    } catch {
      return "invalid JSON";
    }
  }
  function collectStringValues(obj) {
    const strings = [];
    const recurse = (val) => {
      if (typeof val === "string") {
        strings.push(val);
      } else if (Array.isArray(val)) {
        for (const item of val) recurse(item);
      } else if (val && typeof val === "object") {
        for (const k of Object.keys(val)) recurse(val[k]);
      }
    };
    recurse(obj);
    return strings;
  }
  var SAFETY_NET_PATTERNS = [
    { name: "EMAIL", regex: /\b[a-zA-Z0-9_.+-]{1,64}@[a-zA-Z0-9-]{1,63}(?:\.[a-zA-Z0-9-]{1,63})+\b/g },
    { name: "PHONE", regex: /\b(?:\+?\d{1,3}[-.\s]?)?\(?\d{3,4}\)?[-.\s]?\d{3,4}(?:[-.\s]?\d{3,4})?\b/g },
    { name: "API_KEY", regex: /\b(?:sk-[a-zA-Z0-9_-]{12,64}|AKIA[0-9A-Z]{16}|ghp_[a-zA-Z0-9]{36})\b/g },
    { name: "CREDIT_CARD", regex: /\b(?:\d{4}[-\s]?){3}\d{4}\b/g },
    { name: "SSN", regex: /\b\d{3}-\d{2}-\d{4}\b/g },
    { name: "CNIC", regex: /\b\d{5}-\d{7}-\d\b/g },
    { name: "IPV4", regex: /\b(?:\d{1,3}\.){3}\d{1,3}\b/g },
    { name: "IPV6", regex: /\b(?:[A-Fa-f0-9]{1,4}:){7}[A-Fa-f0-9]{1,4}\b/g },
    { name: "MAC_ADDRESS", regex: /\b(?:[0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}\b/g },
    { name: "URL_WITH_CREDS", regex: /https?:\/\/[a-zA-Z0-9_.-]{1,64}:[^@\s]{1,128}@[^\s]+/g },
    { name: "DATE_OF_BIRTH", regex: /\b(?:0[1-9]|1[0-2])[-/](?:0[1-9]|[12]\d|3[01])[-/](?:19|20)\d{2}\b/g }
  ];
  function runSafetyNetScan(text) {
    const hits = [];
    for (const p of SAFETY_NET_PATTERNS) {
      const re = new RegExp(p.regex.source, p.regex.flags);
      let m;
      while ((m = re.exec(text)) !== null) {
        hits.push({ type: p.name, value: `[${p.name} match, length ${m[0].length}]` });
      }
    }
    return hits;
  }
  var cachedSensitiveTermPatterns = [];
  function requestSensitiveTerms() {
    window.postMessage({
      source: "RATCHET_MAIN",
      type: "GET_SENSITIVE_TERMS"
    }, "*");
  }
  window.addEventListener("message", (evt) => {
    if (evt.source !== window || !evt.data || evt.data.source !== "RATCHET_ISOLATED") return;
    if (evt.data.type === "SENSITIVE_TERMS_RESPONSE" && Array.isArray(evt.data.terms)) {
      cachedSensitiveTermPatterns = [];
      for (const term of evt.data.terms) {
        if (typeof term === "string" && term.trim()) {
          const escaped = term.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
          cachedSensitiveTermPatterns.push({
            name: "SENSITIVE_TERM",
            regex: new RegExp(`\\b${escaped}\\b`, "gi")
          });
        }
      }
    }
  });
  function runSensitiveTermsScan(text) {
    const hits = [];
    for (const p of cachedSensitiveTermPatterns) {
      const re = new RegExp(p.regex.source, p.regex.flags);
      let m;
      while ((m = re.exec(text)) !== null) {
        hits.push({ type: p.name, value: `[sensitive term match, length ${m[0].length}]` });
      }
    }
    return hits;
  }
  (() => {
    const adapter = getAdapterForUrl(window.location.href);
    if (!adapter) {
      return;
    }
    if (RATCHET_DEBUG) {
      console.log(`Ratchet: interceptor installed on ${window.location.hostname}`);
    }
    requestSensitiveTerms();
    let tempConvId = `temp-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    function getConversationId() {
      const realId = adapter?.getConversationId(window.location.href);
      if (realId) return realId;
      return tempConvId;
    }
    function anonymizePath(path) {
      return path.replace(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/gi, ":id").replace(/\/[0-9a-f]{24,}/gi, "/:id").replace(/\/\d{10,}/g, "/:id");
    }
    function logDiagnostic(method, url, contentType, rawBody, classification, decision, blockReason) {
      const urlObj = (() => {
        try {
          return new URL(url, window.location.origin);
        } catch {
          return null;
        }
      })();
      const path = urlObj ? anonymizePath(urlObj.pathname) : url;
      let jsonStructure = null;
      if (rawBody && typeof rawBody === "string") {
        try {
          const trimmed = rawBody.trim();
          if (trimmed.startsWith("{") || trimmed.startsWith("[")) {
            jsonStructure = summarizeJson(rawBody);
          }
        } catch {
        }
      }
      window.postMessage({
        source: "RATCHET_MAIN",
        type: "DIAGNOSTIC_LOG",
        payload: {
          timestamp: (/* @__PURE__ */ new Date()).toISOString(),
          method,
          path,
          contentType,
          bodyType: rawBody !== null ? "string" : "null",
          classification,
          decision,
          blockReason: blockReason || null,
          jsonStructure
        }
      }, "*");
    }
    function requestRedaction(prompt, convId, timeoutMs = 7e4) {
      return new Promise((resolve, reject) => {
        const requestId = `req-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
        let timer = null;
        const handler = (evt) => {
          if (evt.source !== window || !evt.data || evt.data.source !== "RATCHET_ISOLATED") {
            return;
          }
          if (evt.data.requestId === requestId) {
            if (timer) clearTimeout(timer);
            window.removeEventListener("message", handler);
            if (evt.data.success && typeof evt.data.redactedText === "string") {
              if (Array.isArray(evt.data.warnings)) {
                for (const warn of evt.data.warnings) {
                  showWarningNotice(warn);
                }
              }
              resolve(evt.data.redactedText);
            } else {
              reject(new Error(evt.data.error || "Redaction failed"));
            }
          }
        };
        window.addEventListener("message", handler);
        timer = setTimeout(() => {
          window.removeEventListener("message", handler);
          reject(new Error("Redaction request timed out"));
        }, timeoutMs);
        window.postMessage(
          {
            source: "RATCHET_MAIN",
            requestId,
            type: "REDACT_REQUEST",
            text: prompt,
            conversationId: convId
          },
          "*"
        );
      });
    }
    async function processRequest(rawBody, method, url, contentType, callStyle) {
      const { classification, extracted } = adapter.classifyRequest(rawBody);
      const urlObj = (() => {
        try {
          return new URL(url, window.location.origin);
        } catch {
          return null;
        }
      })();
      const pathForLog = urlObj ? anonymizePath(urlObj.pathname) : url;
      if (classification === "unknown-message-shape") {
        logDiagnostic(method, url, contentType, rawBody, classification, "blocked", "Unexpected message shape (fail closed)");
        if (RATCHET_DEBUG) console.log(`Ratchet: POST ${pathForLog} -> blocked: Unexpected message shape (fail closed) (style: ${callStyle})`);
        return { action: "block", reason: "Unexpected message shape (fail closed)" };
      }
      if (classification === "message" && extracted) {
        const convId = getConversationId();
        let redactedText;
        try {
          redactedText = await requestRedaction(extracted.prompt, convId);
        } catch (err) {
          const msg = err?.message || "";
          logDiagnostic(method, url, contentType, rawBody, classification, "blocked", msg);
          if (msg.includes("custom rule")) {
            showPrivacyNotice(`Ratchet: Outgoing request blocked (skipped custom rule).`);
          } else if (msg.includes("cancelled")) {
            showWarningNotice("Ratchet: Outgoing prompt cancelled by user.");
          } else if (msg.includes("timed out")) {
            showPrivacyNotice("Ratchet: Outgoing request blocked (review timed out).");
          } else {
            showPrivacyNotice("Ratchet: Outgoing request blocked (redaction failed or timed out).");
          }
          if (RATCHET_DEBUG) console.log(`Ratchet: POST ${pathForLog} -> blocked: ${msg} (style: ${callStyle})`);
          return { action: "block", reason: msg };
        }
        const newBody = extracted.replaceWith(redactedText);
        logDiagnostic(method, url, contentType, rawBody, classification, "redacted");
        if (RATCHET_DEBUG) console.log(`Ratchet: POST ${pathForLog} -> redacted (style: ${callStyle})`);
        return { action: "redact", newBody };
      }
      let allText = rawBody;
      try {
        const parsed = JSON.parse(rawBody);
        const strings = collectStringValues(parsed);
        allText = strings.join(" ");
      } catch {
      }
      const regexHits = runSafetyNetScan(allText);
      const termHits = runSensitiveTermsScan(allText);
      const allHits = [...regexHits, ...termHits];
      if (allHits.length > 0) {
        const hitTypes = [...new Set(allHits.map((h) => h.type))].join(", ");
        const reason = `Possible sensitive data in unrecognized request (${hitTypes})`;
        logDiagnostic(method, url, contentType, rawBody, classification, "blocked", reason);
        if (RATCHET_DEBUG) console.log(`Ratchet: POST ${pathForLog} -> blocked: ${reason} (style: ${callStyle})`);
        return { action: "block", reason };
      }
      logDiagnostic(method, url, contentType, rawBody, classification, "passed-through");
      if (RATCHET_DEBUG) console.log(`Ratchet: POST ${pathForLog} -> passed through (style: ${callStyle})`);
      return { action: "pass" };
    }
    const originalFetch = window.fetch;
    window.fetch = async function(input, init) {
      let url = "";
      let method = "GET";
      if (typeof input === "string") {
        url = input;
        method = init?.method?.toUpperCase() || "GET";
      } else if (input instanceof URL) {
        url = input.toString();
        method = init?.method?.toUpperCase() || "GET";
      } else if (input instanceof Request) {
        url = input.url;
        method = input.method?.toUpperCase() || "GET";
      }
      if (!adapter.matchesRequest(url, method)) {
        return originalFetch.apply(this, arguments);
      }
      let callStyle = "";
      if (typeof input === "string") {
        callStyle = "fetch string URL";
      } else if (input instanceof URL) {
        callStyle = "fetch string URL";
      } else if (input instanceof Request) {
        callStyle = "fetch with a Request object";
      }
      let req;
      try {
        req = new Request(input, init);
      } catch {
        showPrivacyNotice("Ratchet: Outgoing request blocked (unreadable payload).");
        throw new Error("[Ratchet] Outgoing request blocked (unreadable payload)");
      }
      let rawBody = null;
      try {
        rawBody = await req.clone().text();
      } catch {
        rawBody = null;
      }
      if (!rawBody) {
        showPrivacyNotice("Ratchet: Outgoing request blocked (unreadable payload).");
        throw new Error("[Ratchet] Outgoing request blocked (unreadable payload)");
      }
      const contentType = req.headers.get("content-type") || "unknown";
      const result = await processRequest(rawBody, method, url, contentType, callStyle);
      if (result.action === "block") {
        showPrivacyNotice(`Ratchet: Outgoing request blocked (${result.reason}).`);
        throw new Error(`[Ratchet] Outgoing request blocked (${result.reason})`);
      }
      if (result.action === "redact") {
        return originalFetch.call(this, new Request(req, { body: result.newBody }));
      }
      return originalFetch.call(this, req);
    };
    const OriginalXHR = window.XMLHttpRequest;
    const originalOpen = OriginalXHR.prototype.open;
    const originalSend = OriginalXHR.prototype.send;
    OriginalXHR.prototype.open = function(method, url, ...rest) {
      this.__ratchet_method = method;
      this.__ratchet_url = typeof url === "string" ? url : url.toString();
      return originalOpen.apply(this, [method, url, ...rest]);
    };
    OriginalXHR.prototype.send = function(body) {
      const method = this.__ratchet_method || "GET";
      const url = this.__ratchet_url || "";
      if (!adapter.matchesRequest(url, method)) {
        return originalSend.apply(this, arguments);
      }
      if (typeof body !== "string") {
        showPrivacyNotice("Ratchet: Outgoing request blocked (non-string payload).");
        throw new Error("[Ratchet] Outgoing request blocked (non-string payload)");
      }
      const contentType = "unknown (XHR)";
      const callStyle = "XHR";
      processRequest(body, method, url, contentType, callStyle).then((result) => {
        if (result.action === "block") {
          showPrivacyNotice(`Ratchet: Outgoing request blocked (${result.reason}).`);
          try {
            this.abort();
          } catch {
          }
          return;
        }
        if (result.action === "redact") {
          originalSend.call(this, result.newBody);
          return;
        }
        originalSend.call(this, body);
      }).catch((err) => {
        const msg = err?.message || "";
        showPrivacyNotice(`Ratchet: Outgoing request blocked (${msg}).`);
        try {
          this.abort();
        } catch {
        }
      });
    };
  })();
})();
