import{v as a}from"./redos-validator.js";self.onmessage=e=>{const{pattern:s}=e.data,t=a(s);self.postMessage(t)};
