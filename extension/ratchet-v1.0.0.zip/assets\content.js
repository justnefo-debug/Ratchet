"use strict";
(() => {
  var __defProp = Object.defineProperty;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);

  // src/adapters/chatgpt.ts
  var ChatGPTAdapter = class {
    constructor() {
      __publicField(this, "siteName", "ChatGPT");
    }
    matchesPage(url) {
      try {
        const parsed = new URL(url);
        const host = parsed.hostname.toLowerCase();
        return host === "chatgpt.com" || host === "chat.openai.com" || host.endsWith(".chatgpt.com");
      } catch {
        return false;
      }
    }
    matchesRequest(_url, method) {
      if (method && method.toUpperCase() !== "POST") return false;
      return true;
    }
    getConversationId(pageUrl) {
      try {
        const parsed = new URL(pageUrl);
        const match = parsed.pathname.match(/\/c\/([a-zA-Z0-9_-]+)/);
        return match ? match[1] : null;
      } catch {
        const match = pageUrl.match(/\/c\/([a-zA-Z0-9_-]+)/);
        return match ? match[1] : null;
      }
    }
    extractUserPrompt(bodyString) {
      try {
        const body = JSON.parse(bodyString);
        if (!body || typeof body !== "object" || !Array.isArray(body.messages)) {
          return null;
        }
        let foundUserMessage = false;
        for (const m of body.messages) {
          if (m?.author?.role === "user") {
            foundUserMessage = true;
            if (!m.content || !Array.isArray(m.content.parts)) {
              return null;
            }
          }
        }
        if (!foundUserMessage) {
          return null;
        }
        const stringParts = [];
        for (let i = 0; i < body.messages.length; i++) {
          const m = body.messages[i];
          if (m?.author?.role === "user") {
            for (let j = 0; j < m.content.parts.length; j++) {
              if (typeof m.content.parts[j] === "string") {
                stringParts.push({ msgIndex: i, partIndex: j, text: m.content.parts[j] });
              }
            }
          }
        }
        if (stringParts.length === 0) {
          return null;
        }
        const joinedPrompt = stringParts.map((sp) => sp.text).join("\n\n");
        return {
          prompt: joinedPrompt,
          replaceWith: (redactedPrompt) => {
            const newBody = JSON.parse(bodyString);
            if (stringParts.length === 1) {
              const sp = stringParts[0];
              newBody.messages[sp.msgIndex].content.parts[sp.partIndex] = redactedPrompt;
            } else {
              const first = stringParts[0];
              newBody.messages[first.msgIndex].content.parts[first.partIndex] = redactedPrompt;
              for (let i = 1; i < stringParts.length; i++) {
                const sp = stringParts[i];
                newBody.messages[sp.msgIndex].content.parts[sp.partIndex] = "";
              }
            }
            return JSON.stringify(newBody);
          }
        };
      } catch {
        return null;
      }
    }
    classifyRequest(bodyString) {
      try {
        const body = JSON.parse(bodyString);
        if (!body || typeof body !== "object") {
          return { classification: "non-message", extracted: null };
        }
        if ("messages" in body) {
          if (!Array.isArray(body.messages)) {
            return { classification: "unknown-message-shape", extracted: null };
          }
          const extracted = this.extractUserPrompt(bodyString);
          if (extracted) {
            return { classification: "message", extracted };
          }
          return { classification: "unknown-message-shape", extracted: null };
        }
        return { classification: "non-message", extracted: null };
      } catch {
        return { classification: "non-message", extracted: null };
      }
    }
    getMessageSelectors() {
      return [
        '[data-message-author-role="assistant"]',
        '[data-message-author-role="user"]',
        ".agent-turn",
        ".user-turn",
        ".markdown",
        'div[data-testid^="conversation-turn-"]'
      ];
    }
  };

  // src/adapters/claude.ts
  var ClaudeAdapter = class {
    constructor() {
      __publicField(this, "siteName", "Claude");
    }
    matchesPage(url) {
      try {
        const parsed = new URL(url);
        const host = parsed.hostname.toLowerCase();
        return host === "claude.ai" || host.endsWith(".claude.ai");
      } catch {
        return false;
      }
    }
    matchesRequest(url, method) {
      if (method && method.toUpperCase() !== "POST") return false;
      try {
        const base = typeof window !== "undefined" && window.location ? window.location.origin : "https://claude.ai";
        const parsed = new URL(url, base);
        const path = parsed.pathname;
        return path.includes("/api/organizations/") && path.includes("/chat_conversations/") && (path.endsWith("/completion") || path.endsWith("/retry_completion") || path.includes("/completion"));
      } catch {
        return url.includes("/api/organizations/") && url.includes("/chat_conversations/");
      }
    }
    getConversationId(pageUrl) {
      try {
        const parsed = new URL(pageUrl);
        const match = parsed.pathname.match(/\/chat\/([a-zA-Z0-9_-]+)/);
        return match ? match[1] : null;
      } catch {
        const match = pageUrl.match(/\/chat\/([a-zA-Z0-9_-]+)/);
        return match ? match[1] : null;
      }
    }
    extractUserPrompt(bodyString) {
      try {
        const body = JSON.parse(bodyString);
        if (!body || typeof body !== "object") return null;
        if (typeof body.prompt === "string") {
          const originalPrompt = body.prompt;
          return {
            prompt: originalPrompt,
            replaceWith: (redactedPrompt) => {
              const updated = JSON.parse(bodyString);
              updated.prompt = redactedPrompt;
              return JSON.stringify(updated);
            }
          };
        }
        if (Array.isArray(body.messages)) {
          let userIdx = -1;
          for (let i = body.messages.length - 1; i >= 0; i--) {
            const m = body.messages[i];
            if (m?.role === "user") {
              userIdx = i;
              break;
            }
          }
          if (userIdx === -1) return null;
          const userMsg = body.messages[userIdx];
          if (typeof userMsg.content === "string") {
            return {
              prompt: userMsg.content,
              replaceWith: (redactedPrompt) => {
                const updated = JSON.parse(bodyString);
                updated.messages[userIdx].content = redactedPrompt;
                return JSON.stringify(updated);
              }
            };
          }
          if (Array.isArray(userMsg.content) && typeof userMsg.content[0]?.text === "string") {
            return {
              prompt: userMsg.content[0].text,
              replaceWith: (redactedPrompt) => {
                const updated = JSON.parse(bodyString);
                updated.messages[userIdx].content[0].text = redactedPrompt;
                return JSON.stringify(updated);
              }
            };
          }
        }
        return null;
      } catch {
        return null;
      }
    }
    classifyRequest(bodyString) {
      try {
        const body = JSON.parse(bodyString);
        if (!body || typeof body !== "object") {
          return { classification: "non-message", extracted: null };
        }
        if ("prompt" in body || "messages" in body) {
          if ("messages" in body && !Array.isArray(body.messages)) {
            return { classification: "unknown-message-shape", extracted: null };
          }
          const extracted = this.extractUserPrompt(bodyString);
          if (extracted) {
            return { classification: "message", extracted };
          }
          return { classification: "unknown-message-shape", extracted: null };
        }
        return { classification: "non-message", extracted: null };
      } catch {
        return { classification: "non-message", extracted: null };
      }
    }
    getMessageSelectors() {
      return [
        "[data-is-streaming]",
        ".font-claude-message",
        ".font-user-message",
        'div[data-testid="user-message"]',
        "div[data-test-render-count]",
        ".standard-markdown",
        'div[class*="ChatMessage"]'
      ];
    }
  };

  // src/adapters/index.ts
  var ADAPTERS = [
    new ChatGPTAdapter(),
    new ClaudeAdapter()
  ];
  if (false) {
    ADAPTERS.push(new MockSiteAdapter());
  }
  function getAdapterForUrl(url) {
    for (const adapter of ADAPTERS) {
      if (adapter.matchesPage(url)) {
        return adapter;
      }
    }
    return null;
  }

  // src/content/review-panel.ts
  var activePanelCleanup = null;
  function showReviewPanel(options) {
    if (activePanelCleanup) {
      activePanelCleanup();
    }
    const timeoutSeconds = options.timeoutSeconds ?? 60;
    let remainingSeconds = timeoutSeconds;
    const unredactedStates = options.items.map(() => false);
    const sessionExemptions = options.items.map(() => false);
    const host = document.createElement("div");
    host.id = "ratchet-review-host";
    Object.assign(host.style, {
      all: "initial",
      position: "fixed",
      top: "0",
      left: "0",
      width: "100vw",
      height: "100vh",
      zIndex: "2147483647",
      pointerEvents: "auto"
    });
    const shadow = host.attachShadow({ mode: "closed" });
    const style = document.createElement("style");
    style.textContent = `
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    }
    .backdrop {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(15, 23, 42, 0.72);
      backdrop-filter: blur(8px);
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
      animation: fadeIn 0.2s ease-out;
    }
    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }
    .modal {
      background: #0f172a;
      border: 1px solid #334155;
      border-radius: 14px;
      width: 100%;
      max-width: 620px;
      max-height: 88vh;
      display: flex;
      flex-direction: column;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.65), 0 0 0 1px rgba(255, 255, 255, 0.05);
      color: #f8fafc;
      overflow: hidden;
      animation: slideUp 0.25s cubic-bezier(0.16, 1, 0.3, 1);
    }
    @keyframes slideUp {
      from { opacity: 0; transform: translateY(16px) scale(0.98); }
      to { opacity: 1; transform: translateY(0) scale(1); }
    }
    .header {
      padding: 20px 24px 16px;
      border-bottom: 1px solid #1e293b;
      display: flex;
      align-items: flex-start;
      justify-content: space-between;
      gap: 12px;
    }
    .title-area {
      display: flex;
      align-items: center;
      gap: 10px;
    }
    .shield-badge {
      font-size: 20px;
      line-height: 1;
    }
    .title {
      font-size: 17px;
      font-weight: 700;
      letter-spacing: -0.01em;
      color: #f1f5f9;
    }
    .subtitle {
      font-size: 13px;
      color: #94a3b8;
      margin-top: 4px;
    }
    .timer-badge {
      display: inline-flex;
      align-items: center;
      padding: 4px 10px;
      background: rgba(245, 158, 11, 0.12);
      border: 1px solid rgba(245, 158, 11, 0.3);
      color: #fbbf24;
      border-radius: 9999px;
      font-size: 12px;
      font-weight: 600;
      white-space: nowrap;
    }
    .content {
      padding: 20px 24px;
      overflow-y: auto;
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 14px;
    }
    .items-count-banner {
      font-size: 13px;
      color: #cbd5e1;
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 8px 12px;
      background: rgba(30, 41, 59, 0.6);
      border-radius: 8px;
    }
    .items-list {
      display: flex;
      flex-direction: column;
      gap: 10px;
    }
    .item-card {
      background: #1e293b;
      border: 1px solid #334155;
      border-radius: 10px;
      padding: 12px 14px;
      display: flex;
      flex-direction: column;
      gap: 8px;
      transition: border-color 0.15s ease;
    }
    .item-card.unredacted {
      border-color: #f59e0b;
      background: rgba(245, 158, 11, 0.05);
    }
    .item-top {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
    }
    .cat-badge {
      font-size: 11px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      padding: 2px 7px;
      border-radius: 5px;
      background: #3b82f6;
      color: #ffffff;
    }
    .cat-badge.person { background: #8b5cf6; }
    .cat-badge.org { background: #0ea5e9; }
    .cat-badge.location { background: #10b981; }
    .cat-badge.api_key { background: #f43f5e; }
    .cat-badge.credit_card { background: #ec4899; }
    .cat-badge.phone { background: #14b8a6; }
    .cat-badge.ssn, .cat-badge.cnic { background: #ef4444; }
    .cat-badge.email { background: #6366f1; }

    .btn-toggle-unredact {
      background: transparent;
      border: 1px solid #475569;
      color: #cbd5e1;
      border-radius: 6px;
      padding: 4px 10px;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.15s ease;
    }
    .btn-toggle-unredact:hover {
      background: #334155;
      color: #ffffff;
    }
    .btn-toggle-unredact.active {
      background: #f59e0b;
      border-color: #f59e0b;
      color: #0f172a;
    }
    .item-details {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 13px;
      word-break: break-all;
    }
    .orig-val {
      color: #f87171;
      background: rgba(239, 68, 68, 0.12);
      padding: 2px 6px;
      border-radius: 4px;
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    }
    .item-card.unredacted .orig-val {
      color: #4ade80;
      background: rgba(74, 222, 128, 0.12);
    }
    .arrow {
      color: #64748b;
      font-weight: 700;
    }
    .placeholder-val {
      color: #38bdf8;
      background: rgba(56, 189, 248, 0.12);
      padding: 2px 6px;
      border-radius: 4px;
      font-weight: 600;
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    }
    .item-card.unredacted .placeholder-val {
      text-decoration: line-through;
      color: #64748b;
      background: transparent;
    }
    .session-exempt-row {
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: 12px;
      color: #94a3b8;
      margin-top: 2px;
    }
    .session-exempt-row input {
      accent-color: #6366f1;
      cursor: pointer;
    }
    .footer {
      padding: 16px 24px;
      border-top: 1px solid #1e293b;
      background: rgba(15, 23, 42, 0.95);
      display: flex;
      align-items: center;
      justify-content: flex-end;
      gap: 10px;
    }
    .btn {
      padding: 8px 16px;
      border-radius: 8px;
      font-size: 13px;
      font-weight: 600;
      cursor: pointer;
      border: 1px solid transparent;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      transition: all 0.15s ease;
    }
    .btn-cancel {
      background: #1e293b;
      border-color: #334155;
      color: #cbd5e1;
    }
    .btn-cancel:hover {
      background: #334155;
      color: #ffffff;
    }
    .btn-asis {
      background: rgba(245, 158, 11, 0.12);
      border-color: rgba(245, 158, 11, 0.3);
      color: #fbbf24;
    }
    .btn-asis:hover {
      background: rgba(245, 158, 11, 0.22);
    }
    .btn-send {
      background: #4f46e5;
      color: #ffffff;
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.3);
    }
    .btn-send:hover {
      background: #4338ca;
    }
    .confirm-box {
      background: rgba(239, 68, 68, 0.1);
      border: 1px solid rgba(239, 68, 68, 0.3);
      border-radius: 8px;
      padding: 12px;
      margin-top: 10px;
      display: none;
      flex-direction: column;
      gap: 8px;
    }
    .confirm-box.visible {
      display: flex;
    }
    .confirm-title {
      font-size: 13px;
      font-weight: 700;
      color: #f87171;
    }
    .confirm-desc {
      font-size: 12px;
      color: #fca5a5;
    }
    .confirm-actions {
      display: flex;
      gap: 8px;
      justify-content: flex-end;
    }
    .btn-confirm-yes {
      background: #dc2626;
      color: #fff;
    }
    .btn-confirm-no {
      background: #334155;
      color: #e2e8f0;
    }
    .skipped-rules-banner {
      background: rgba(239, 68, 68, 0.15);
      border: 1px solid #ef4444;
      border-radius: 8px;
      padding: 12px 14px;
      color: #fca5a5;
      font-size: 13px;
      line-height: 1.4;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .skipped-rules-banner .banner-title {
      font-weight: 700;
      color: #f87171;
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: 13px;
    }
    .skipped-rules-banner .rules-list {
      margin-left: 20px;
      margin-top: 4px;
      color: #fecaca;
      font-size: 12px;
    }
    .preview-section {
      background: #090d16;
      border: 1px solid #1e293b;
      border-radius: 8px;
      padding: 10px 14px;
      display: flex;
      flex-direction: column;
      gap: 8px;
    }
    .preview-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      font-size: 11px;
      font-weight: 600;
      color: #94a3b8;
      text-transform: uppercase;
      letter-spacing: 0.04em;
    }
    .preview-box {
      font-size: 13px;
      line-height: 1.5;
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
      color: #e2e8f0;
      user-select: text;
      white-space: pre-wrap;
      word-break: break-word;
      max-height: 120px;
      overflow-y: auto;
      padding: 8px 10px;
      background: rgba(30, 41, 59, 0.4);
      border-radius: 6px;
      border: 1px solid rgba(51, 65, 85, 0.4);
    }
    .preview-box::selection {
      background: #4f46e5;
      color: #ffffff;
    }
    .manual-toolbar {
      display: none;
      background: #1e293b;
      border: 1px solid #475569;
      border-radius: 6px;
      padding: 8px 10px;
      align-items: center;
      gap: 8px;
      font-size: 12px;
      flex-wrap: wrap;
    }
    .manual-toolbar.active {
      display: flex;
    }
    .manual-selected-text {
      color: #38bdf8;
      font-weight: 600;
      max-width: 130px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .manual-cat-select {
      background: #0f172a;
      border: 1px solid #475569;
      color: #f8fafc;
      font-size: 11px;
      padding: 3px 6px;
      border-radius: 4px;
    }
    .manual-btn-redact {
      background: #6366f1;
      border: none;
      color: #fff;
      font-size: 11px;
      font-weight: 600;
      padding: 4px 10px;
      border-radius: 4px;
      cursor: pointer;
    }
    .manual-btn-redact:hover {
      background: #4f46e5;
    }
    .manual-add-terms-label {
      display: inline-flex;
      align-items: center;
      gap: 4px;
      font-size: 11px;
      color: #cbd5e1;
      cursor: pointer;
    }
  `;
    shadow.appendChild(style);
    const backdrop = document.createElement("div");
    backdrop.className = "backdrop";
    const modal = document.createElement("div");
    modal.className = "modal";
    modal.setAttribute("role", "dialog");
    modal.setAttribute("aria-modal", "true");
    modal.setAttribute("aria-labelledby", "ratchet-panel-title");
    const header = document.createElement("div");
    header.className = "header";
    const hasSkipped = options.skippedRules && options.skippedRules.length > 0;
    const subtitleText = hasSkipped ? "\u26A0\uFE0F Warning: One or more custom rules were skipped. Review prompt before sending." : "Ratchet detected sensitive data. Choose what gets redacted before sending.";
    const titleArea = document.createElement("div");
    titleArea.className = "title-area";
    titleArea.innerHTML = `
    <span class="shield-badge">\u{1F6E1}\uFE0F</span>
    <div>
      <div id="ratchet-panel-title" class="title">Review Outgoing Prompt</div>
      <div class="subtitle">${subtitleText}</div>
    </div>
  `;
    const timerBadge = document.createElement("div");
    timerBadge.className = "timer-badge";
    timerBadge.id = "ratchet-timer-badge";
    timerBadge.textContent = `Cancels in ${remainingSeconds}s`;
    header.appendChild(titleArea);
    header.appendChild(timerBadge);
    modal.appendChild(header);
    const content = document.createElement("div");
    content.className = "content";
    if (hasSkipped) {
      const skippedBanner = document.createElement("div");
      skippedBanner.className = "skipped-rules-banner";
      skippedBanner.id = "ratchet-skipped-rules-warning";
      skippedBanner.innerHTML = `
      <div class="banner-title">
        <span>\u26A0\uFE0F</span>
        <span>Custom Rule Skipped \u2014 Prompt Not Fully Protected</span>
      </div>
      <div>
        The following custom rule(s) were skipped (unsafe syntax or execution time budget exceeded):
        <ul class="rules-list">
          ${options.skippedRules.map((r) => `<li><strong>${escapeHtml(r)}</strong></li>`).join("")}
        </ul>
        <div style="font-size: 11px; color: #fca5a5; margin-top: 4px;">
          Unchecked data matching these rules may remain in your prompt. Review before sending or cancel.
        </div>
      </div>
    `;
      content.appendChild(skippedBanner);
    }
    const countBanner = document.createElement("div");
    countBanner.className = "items-count-banner";
    countBanner.innerHTML = options.items.length > 0 ? `<span><strong>${options.items.length}</strong> items detected</span>
       <span style="font-size: 12px; color: #94a3b8;">Original values stay local</span>` : `<span><strong>0</strong> standard items detected</span>
       <span style="font-size: 12px; color: #f87171;">Custom rule skipped</span>`;
    content.appendChild(countBanner);
    let currentRedactedText = options.redactedText;
    const manualMappings = [];
    const previewSection = document.createElement("div");
    previewSection.className = "preview-section";
    previewSection.id = "ratchet-preview-section";
    const previewHeader = document.createElement("div");
    previewHeader.className = "preview-header";
    previewHeader.innerHTML = `
    <span>Prompt Preview</span>
    <span style="font-size: 11px; color: #64748b; font-weight: normal; text-transform: none;">Select text to redact</span>
  `;
    const previewBox = document.createElement("div");
    previewBox.id = "ratchet-preview-text";
    previewBox.className = "preview-box";
    previewBox.textContent = currentRedactedText;
    const manualToolbar = document.createElement("div");
    manualToolbar.id = "ratchet-manual-toolbar";
    manualToolbar.className = "manual-toolbar";
    manualToolbar.innerHTML = `
    <span>Selected:</span>
    <span id="ratchet-selected-text" class="manual-selected-text"></span>
    <select id="ratchet-manual-category" class="manual-cat-select">
      <option value="PERSON">Name (PERSON)</option>
      <option value="ORG">Employer (ORG)</option>
      <option value="PROJECT">Project (PROJECT)</option>
      <option value="LOCATION">Place (LOCATION)</option>
    </select>
    <label class="manual-add-terms-label">
      <input type="checkbox" id="ratchet-cb-add-terms" checked />
      <span>Also add to My sensitive terms</span>
    </label>
    <button type="button" id="ratchet-btn-manual-redact" class="manual-btn-redact">
      Redact All Occurrences
    </button>
  `;
    previewSection.appendChild(previewHeader);
    previewSection.appendChild(previewBox);
    previewSection.appendChild(manualToolbar);
    content.appendChild(previewSection);
    const itemsList = document.createElement("div");
    itemsList.className = "items-list";
    const renderItemCard = (item, idx) => {
      const card = document.createElement("div");
      card.className = "item-card";
      card.id = `ratchet-item-${idx}`;
      const catClass = item.category.toLowerCase().replace(/[^a-z0-9_]/g, "");
      card.innerHTML = `
      <div class="item-top">
        <span class="cat-badge ${catClass}">${escapeHtml(item.category)}</span>
        <button type="button" class="btn-toggle-unredact" data-idx="${idx}">
          Un-redact
        </button>
      </div>
      <div class="item-details">
        <span class="orig-val">${escapeHtml(item.original)}</span>
        <span class="arrow">\u2794</span>
        <span class="placeholder-val">${escapeHtml(item.placeholder)}</span>
      </div>
      <label class="session-exempt-row">
        <input type="checkbox" class="session-exempt-cb" data-idx="${idx}">
        <span>Don't redact this again this session</span>
      </label>
    `;
      const toggleBtn = card.querySelector(".btn-toggle-unredact");
      if (toggleBtn) {
        toggleBtn.addEventListener("click", () => {
          unredactedStates[idx] = !unredactedStates[idx];
          if (unredactedStates[idx]) {
            card.classList.add("unredacted");
            toggleBtn.classList.add("active");
            toggleBtn.textContent = "Keep Original \u2713";
          } else {
            card.classList.remove("unredacted");
            toggleBtn.classList.remove("active");
            toggleBtn.textContent = "Un-redact";
          }
        });
      }
      const exemptCb = card.querySelector(".session-exempt-cb");
      if (exemptCb) {
        exemptCb.addEventListener("change", () => {
          sessionExemptions[idx] = exemptCb.checked;
        });
      }
      itemsList.appendChild(card);
    };
    options.items.forEach((item, idx) => {
      renderItemCard(item, idx);
    });
    let selectedPhrase = "";
    const selectedTextSpan = manualToolbar.querySelector("#ratchet-selected-text");
    const catSelect = manualToolbar.querySelector("#ratchet-manual-category");
    const cbAddTerms = manualToolbar.querySelector("#ratchet-cb-add-terms");
    const btnManualRedact = manualToolbar.querySelector("#ratchet-btn-manual-redact");
    const handleSelection = () => {
      const sel = shadow.getSelection ? shadow.getSelection() : window.getSelection();
      const str = sel ? sel.toString().trim() : "";
      if (str.length > 0 && !str.includes("\xAB") && !str.includes("\xBB")) {
        selectedPhrase = str;
        selectedTextSpan.textContent = `"${str}"`;
        manualToolbar.classList.add("active");
      }
    };
    previewBox.addEventListener("mouseup", handleSelection);
    previewBox.addEventListener("keyup", handleSelection);
    shadow.addEventListener("mouseup", handleSelection);
    btnManualRedact.addEventListener("click", () => {
      if (!selectedPhrase) return;
      const phrase = selectedPhrase;
      const cat = catSelect.value;
      const addTerms = cbAddTerms.checked;
      const catCount = options.items.filter((i) => i.category === cat).length + 1;
      const placeholder = `\xAB${cat}_${catCount}\xBB`;
      const escaped = escapeRegex(phrase);
      const re = new RegExp(`\\b${escaped}(?:['\u2019]s\\b|['\u2019](?!\\w)|\\b)`, "gi");
      currentRedactedText = currentRedactedText.replace(re, placeholder);
      previewBox.textContent = currentRedactedText;
      const newItem = {
        category: cat,
        original: phrase,
        placeholder
      };
      const newIdx = options.items.length;
      options.items.push(newItem);
      unredactedStates.push(false);
      sessionExemptions.push(false);
      manualMappings.push({
        placeholder,
        original: phrase,
        type: cat
      });
      renderItemCard(newItem, newIdx);
      countBanner.innerHTML = `<span><strong>${options.items.length}</strong> items detected</span>
      <span style="font-size: 12px; color: #94a3b8;">Original values stay local</span>`;
      if (addTerms && options.onAddSensitiveTerm) {
        options.onAddSensitiveTerm(phrase, cat);
      }
      selectedPhrase = "";
      manualToolbar.classList.remove("active");
    });
    content.appendChild(itemsList);
    const confirmBox = document.createElement("div");
    confirmBox.className = "confirm-box";
    confirmBox.id = "ratchet-confirm-asis-box";
    confirmBox.innerHTML = `
    <div class="confirm-title">\u26A0\uFE0F Send unredacted data over the wire?</div>
    <div class="confirm-desc">All sensitive items will be sent in plain text without protection.</div>
    <div class="confirm-actions">
      <button type="button" class="btn btn-confirm-no" id="ratchet-confirm-no">Back</button>
      <button type="button" class="btn btn-confirm-yes" id="ratchet-confirm-yes">Send As-Is Now</button>
    </div>
  `;
    content.appendChild(confirmBox);
    modal.appendChild(content);
    const footer = document.createElement("div");
    footer.className = "footer";
    const cancelBtn = document.createElement("button");
    cancelBtn.type = "button";
    cancelBtn.id = "ratchet-btn-cancel";
    cancelBtn.className = "btn btn-cancel";
    cancelBtn.textContent = "Cancel (Esc)";
    const sendAsIsBtn = document.createElement("button");
    sendAsIsBtn.type = "button";
    sendAsIsBtn.id = "ratchet-btn-asis";
    sendAsIsBtn.className = "btn btn-asis";
    sendAsIsBtn.textContent = "Send As-Is";
    const sendRedactedBtn = document.createElement("button");
    sendRedactedBtn.type = "button";
    sendRedactedBtn.id = "ratchet-btn-send";
    sendRedactedBtn.className = "btn btn-send";
    sendRedactedBtn.textContent = "Send Redacted (Enter)";
    footer.appendChild(cancelBtn);
    footer.appendChild(sendAsIsBtn);
    footer.appendChild(sendRedactedBtn);
    modal.appendChild(footer);
    backdrop.appendChild(modal);
    shadow.appendChild(backdrop);
    document.documentElement.appendChild(host);
    let isClosed = false;
    const closePanel = () => {
      if (isClosed) return;
      isClosed = true;
      clearInterval(timerInterval);
      window.removeEventListener("keydown", handleKeydown, true);
      if (host.parentElement) {
        host.remove();
      }
      if (activePanelCleanup === closePanel) {
        activePanelCleanup = null;
      }
    };
    const handleSendRedacted = () => {
      let finalWireText = currentRedactedText;
      options.items.forEach((item, idx) => {
        if (unredactedStates[idx]) {
          finalWireText = finalWireText.split(item.placeholder).join(item.original);
        }
        if (sessionExemptions[idx] && options.onSessionExempt) {
          options.onSessionExempt(item.original);
        }
      });
      closePanel();
      options.onSend(finalWireText, manualMappings);
    };
    const handleCancel = (reason) => {
      closePanel();
      options.onCancel(reason);
    };
    const handleSendAsIs = () => {
      confirmBox.classList.add("visible");
    };
    sendRedactedBtn.addEventListener("click", handleSendRedacted);
    cancelBtn.addEventListener("click", () => handleCancel("user_cancelled"));
    sendAsIsBtn.addEventListener("click", handleSendAsIs);
    confirmBox.querySelector("#ratchet-confirm-no")?.addEventListener("click", () => {
      confirmBox.classList.remove("visible");
    });
    confirmBox.querySelector("#ratchet-confirm-yes")?.addEventListener("click", () => {
      closePanel();
      options.onSend(options.originalText);
    });
    const handleKeydown = (e) => {
      if (e.key === "Escape") {
        e.preventDefault();
        e.stopPropagation();
        handleCancel("user_cancelled");
      } else if (e.key === "Enter" && !e.shiftKey) {
        if (confirmBox.classList.contains("visible")) {
          e.preventDefault();
          e.stopPropagation();
          closePanel();
          options.onSend(options.originalText);
        } else {
          e.preventDefault();
          e.stopPropagation();
          handleSendRedacted();
        }
      }
    };
    window.addEventListener("keydown", handleKeydown, true);
    const timerInterval = setInterval(() => {
      remainingSeconds--;
      if (timerBadge) {
        timerBadge.textContent = `Cancels in ${remainingSeconds}s`;
      }
      if (remainingSeconds <= 0) {
        clearInterval(timerInterval);
        handleCancel("timeout");
      }
    }, 1e3);
    activePanelCleanup = closePanel;
    return { close: closePanel };
  }
  function escapeHtml(str) {
    return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }
  function escapeRegex(str) {
    return str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }

  // src/content/interceptor.ts
  var ContentInterceptor = class {
    constructor() {
      __publicField(this, "adapter", getAdapterForUrl(window.location.href));
      __publicField(this, "currentUrl", window.location.href);
      __publicField(this, "pendingTempId", null);
      /** Ephemeral session-only list of values exempted from redaction */
      __publicField(this, "sessionExemptions", /* @__PURE__ */ new Set());
      this.initMessageBridge();
      this.initUrlWatcher();
    }
    isReviewEnabledForOrigin(origin, settings) {
      if (!settings) return false;
      if (settings.reviewBeforeSend === false) return false;
      const lower = origin.toLowerCase();
      const sites = settings.reviewSites || {};
      if (lower.includes("chatgpt.com") || lower.includes("chat.openai.com")) {
        return sites.chatgpt !== false;
      }
      if (lower.includes("claude.ai")) {
        return sites.claude !== false;
      }
      if (lower.includes("gemini.google.com")) {
        return sites.gemini !== false;
      }
      if (false) {
        return sites.mock === true;
      }
      return true;
    }
    initMessageBridge() {
      window.addEventListener("message", (evt) => {
        if (evt.source !== window || !evt.data || evt.data.source !== "RATCHET_MAIN") {
          return;
        }
        if (evt.data.type === "DIAGNOSTIC_LOG") {
          try {
            chrome.runtime.sendMessage({
              action: "diagnosticLog",
              payload: evt.data.payload
            });
          } catch {
          }
          return;
        }
        if (evt.data.type === "GET_SENSITIVE_TERMS") {
          try {
            chrome.runtime.sendMessage({ action: "getSettings" }, (resp) => {
              const terms = resp?.data?.sensitiveTerms || [];
              const termStrings = terms.filter((t) => t.enabled && t.term).map((t) => t.term);
              window.postMessage({
                source: "RATCHET_ISOLATED",
                type: "SENSITIVE_TERMS_RESPONSE",
                terms: termStrings
              }, "*");
            });
          } catch {
          }
          return;
        }
        if (evt.data.type === "REDACT_REQUEST") {
          const { requestId, text, conversationId } = evt.data;
          if (typeof conversationId === "string" && conversationId.startsWith("temp-")) {
            this.pendingTempId = conversationId;
          }
          try {
            chrome.runtime.sendMessage(
              {
                action: "redact",
                text,
                conversationId,
                siteOrigin: window.location.origin
              },
              (response) => {
                if (chrome.runtime.lastError || !response || !response.success) {
                  window.postMessage(
                    {
                      source: "RATCHET_ISOLATED",
                      requestId,
                      success: false,
                      error: chrome.runtime.lastError?.message || response?.error || "Redaction service unavailable"
                    },
                    "*"
                  );
                  return;
                }
                chrome.runtime.sendMessage({ action: "getSettings" }, (settingsResp) => {
                  const settings = settingsResp?.data;
                  const reviewEnabled = this.isReviewEnabledForOrigin(window.location.origin, settings);
                  const rawMappings = response.data.mappings || [];
                  const skippedRules = response.data?.skippedRules || [];
                  const hasSkippedRules = skippedRules.length > 0;
                  const reviewItems = [];
                  let currentRedactedText = response.data.redactedText;
                  for (const m of rawMappings) {
                    if (this.sessionExemptions.has(m.original)) {
                      currentRedactedText = currentRedactedText.split(m.placeholder).join(m.original);
                    } else {
                      reviewItems.push({
                        category: m.type,
                        original: m.original,
                        placeholder: m.placeholder
                      });
                    }
                  }
                  if (reviewEnabled && reviewItems.length > 0 || hasSkippedRules) {
                    showReviewPanel({
                      items: reviewItems,
                      originalText: text,
                      redactedText: currentRedactedText,
                      skippedRules,
                      warnings: response.data?.warnings || [],
                      timeoutSeconds: settings?.reviewTimeoutSeconds ?? 60,
                      onSend: async (finalWireText, manualMappings) => {
                        if (manualMappings && manualMappings.length > 0) {
                          await new Promise((resolve) => {
                            chrome.runtime.sendMessage(
                              {
                                action: "addMappingEntries",
                                conversationId,
                                siteOrigin: window.location.origin,
                                newEntries: manualMappings
                              },
                              () => resolve()
                            );
                          });
                        }
                        window.dispatchEvent(new CustomEvent("ratchet:mapping-updated"));
                        window.postMessage(
                          {
                            source: "RATCHET_ISOLATED",
                            requestId,
                            success: true,
                            redactedText: finalWireText,
                            warnings: response.data.warnings || []
                          },
                          "*"
                        );
                      },
                      onCancel: (reason) => {
                        window.postMessage(
                          {
                            source: "RATCHET_ISOLATED",
                            requestId,
                            success: false,
                            error: reason === "timeout" ? "Review timed out (fail-closed)" : hasSkippedRules ? `Prompt blocked: custom rule(s) "${skippedRules.join(", ")}" were skipped` : "Prompt cancelled by user"
                          },
                          "*"
                        );
                      },
                      onSessionExempt: (val) => {
                        this.sessionExemptions.add(val);
                      },
                      onAddSensitiveTerm: (term, category) => {
                        chrome.runtime.sendMessage({
                          action: "addSensitiveTerm",
                          term: { term, category }
                        });
                      }
                    });
                  } else {
                    window.dispatchEvent(new CustomEvent("ratchet:mapping-updated"));
                    window.postMessage(
                      {
                        source: "RATCHET_ISOLATED",
                        requestId,
                        success: true,
                        redactedText: currentRedactedText,
                        warnings: response.data.warnings || []
                      },
                      "*"
                    );
                  }
                });
              }
            );
          } catch (err) {
            window.postMessage(
              {
                source: "RATCHET_ISOLATED",
                requestId,
                success: false,
                error: err?.message || "Failed to dispatch message to background worker"
              },
              "*"
            );
          }
        }
      });
    }
    initUrlWatcher() {
      const checkUrl = () => {
        if (window.location.href !== this.currentUrl) {
          this.currentUrl = window.location.href;
          if (this.pendingTempId && this.adapter) {
            const realId = this.adapter.getConversationId(this.currentUrl);
            if (realId) {
              chrome.runtime.sendMessage({
                action: "migrateMapping",
                fromId: this.pendingTempId,
                toId: realId
              });
              this.pendingTempId = null;
            }
          }
        }
      };
      window.addEventListener("popstate", checkUrl);
      window.addEventListener("hashchange", checkUrl);
      setInterval(checkUrl, 1e3);
    }
  };

  // src/core/restorer.ts
  function restore(text, mappings) {
    if (mappings.length === 0 || !text) return text;
    let result = text;
    const unmatched = [];
    for (const entry of mappings) {
      if (result.includes(entry.placeholder)) {
        result = result.split(entry.placeholder).join(entry.original);
      } else {
        unmatched.push(entry);
      }
    }
    for (const entry of unmatched) {
      const bare = entry.placeholder.replace(/^«/, "").replace(/»$/, "");
      const underscoreToSpace = bare.replace(/_/g, " ");
      const alts = [
        bare,
        underscoreToSpace
      ].map((s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"));
      const pattern = new RegExp(
        `\xAB\\s*(?:${alts.join("|")})s?\\s*\xBB|\\[\\s*(?:${alts.join("|")})s?\\s*\\]|\\b(?:${alts.join("|")})s?\\b`,
        // bare word variants
        "gi"
      );
      result = result.replace(pattern, entry.original);
    }
    return result;
  }

  // src/content/restorer.ts
  var ContentRestorer = class {
    constructor() {
      __publicField(this, "adapter", getAdapterForUrl(window.location.href));
      __publicField(this, "cachedMappings", []);
      __publicField(this, "isRestoring", false);
      __publicField(this, "currentConvId", null);
      __publicField(this, "restoreRequested", false);
      __publicField(this, "isUpdatingMappings", false);
      this.init();
    }
    init() {
      if (!this.adapter) return;
      this.updateMappings();
      const rootObserver = new MutationObserver((mutations) => {
        if (this.isRestoring) return;
        this.handleMutations(mutations);
      });
      rootObserver.observe(document.body || document.documentElement, {
        childList: true,
        characterData: true,
        subtree: true
      });
      window.addEventListener("focus", () => this.updateMappings());
      window.addEventListener("ratchet:mapping-updated", () => this.updateMappings());
      this.scheduleRestore();
    }
    getCurrentConversationId() {
      return this.currentConvId;
    }
    updateMappings() {
      if (!this.adapter || this.isUpdatingMappings) return;
      const convId = this.adapter.getConversationId(window.location.href) || "default";
      this.currentConvId = convId;
      this.isUpdatingMappings = true;
      try {
        chrome.runtime.sendMessage({ action: "getMapping", conversationId: convId }, (res) => {
          this.isUpdatingMappings = false;
          if (res && res.success && Array.isArray(res.data?.mappings)) {
            this.cachedMappings = res.data.mappings;
            this.scheduleRestore();
          }
        });
      } catch {
        this.isUpdatingMappings = false;
      }
    }
    isEditable(element) {
      const tag = element.tagName.toLowerCase();
      if (tag === "textarea" || tag === "input") return true;
      if (element.getAttribute("contenteditable") === "true") return true;
      if (element.isContentEditable) return true;
      if (element.classList && element.classList.contains("ProseMirror")) return true;
      if (element.closest && element.closest('textarea, input, [contenteditable="true"], .ProseMirror')) {
        return true;
      }
      return false;
    }
    handleMutations(mutations) {
      if (this.cachedMappings.length === 0) {
        this.updateMappings();
        return;
      }
      let needsRestore = false;
      let mightHaveNewPlaceholder = false;
      for (const m of mutations) {
        if (m.type === "characterData" && m.target.nodeValue) {
          if (this.hasAnyPlaceholder(m.target.nodeValue)) {
            needsRestore = true;
            break;
          } else if (m.target.nodeValue.includes("\xAB") || /[A-Z0-9_]{3,}_\d+/.test(m.target.nodeValue)) {
            mightHaveNewPlaceholder = true;
          }
        } else if (m.type === "childList") {
          needsRestore = true;
          break;
        }
      }
      if (needsRestore) {
        this.scheduleRestore();
      } else if (mightHaveNewPlaceholder) {
        this.updateMappings();
      }
    }
    hasAnyPlaceholder(text) {
      for (const m of this.cachedMappings) {
        if (text.includes(m.placeholder)) return true;
        const bare = m.placeholder.replace(/^«/, "").replace(/»$/, "");
        if (text.includes(bare)) return true;
      }
      return false;
    }
    scheduleRestore() {
      if (this.restoreRequested || this.isRestoring || this.cachedMappings.length === 0) return;
      this.restoreRequested = true;
      requestAnimationFrame(() => {
        this.restoreRequested = false;
        this.performRestore();
      });
    }
    performRestore() {
      this.isRestoring = true;
      try {
        const walker = document.createTreeWalker(
          document.body || document.documentElement,
          NodeFilter.SHOW_TEXT,
          {
            acceptNode: (node) => {
              if (node.parentElement && this.isEditable(node.parentElement)) {
                return NodeFilter.FILTER_REJECT;
              }
              return NodeFilter.FILTER_ACCEPT;
            }
          }
        );
        const textNodes = [];
        let currentNode = walker.nextNode();
        while (currentNode) {
          textNodes.push(currentNode);
          currentNode = walker.nextNode();
        }
        const groups = [];
        let currentGroup = [];
        for (const node of textNodes) {
          if (currentGroup.length === 0) {
            currentGroup.push(node);
          } else {
            const lastNode = currentGroup[currentGroup.length - 1];
            if (node.parentNode === lastNode.parentNode && node.previousSibling === lastNode) {
              currentGroup.push(node);
            } else {
              groups.push(currentGroup);
              currentGroup = [node];
            }
          }
        }
        if (currentGroup.length > 0) {
          groups.push(currentGroup);
        }
        for (const group of groups) {
          if (group.length === 1) {
            const orig = group[0].nodeValue || "";
            if (this.hasAnyPlaceholder(orig)) {
              const restored = restore(orig, this.cachedMappings);
              if (restored !== orig) {
                group[0].nodeValue = restored;
              }
            }
          } else {
            const combined = group.map((n) => n.nodeValue || "").join("");
            if (this.hasAnyPlaceholder(combined)) {
              const restored = restore(combined, this.cachedMappings);
              if (restored !== combined) {
                group[0].nodeValue = restored;
                for (let i = 1; i < group.length; i++) {
                  group[i].nodeValue = "";
                }
              }
            }
          }
        }
      } finally {
        this.isRestoring = false;
      }
    }
  };

  // src/content/index.ts
  console.log("\u{1F6E1}\uFE0F Ratchet Privacy Shield: Content script loaded (ISOLATED world)");
  new ContentInterceptor();
  new ContentRestorer();
})();
